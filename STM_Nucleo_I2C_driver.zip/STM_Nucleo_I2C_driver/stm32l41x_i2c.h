/**
 ******************************************************************************
 * @file    stm32l41x_i2c.h
 * @brief   I2C driver for STM32L41xxx series microcontrollers
 *
 * Supports:
 *   - I2C1, I2C3 (STM32L41xxx has 2 I2C peripherals)
 *   - Standard Mode   (Sm)  : 100 kHz
 *   - Fast Mode       (Fm)  : 400 kHz
 *   - Fast Mode Plus  (Fm+) : 1 MHz
 *   - 7-bit and 10-bit addressing
 *   - Master Transmit / Master Receive
 *   - Slave Transmit / Slave Receive
 *   - DMA and Interrupt modes
 *   - Repeated START (combined transactions)
 *   - SMBus support (optional)
 *
 * Reference: STM32L41xxx Reference Manual (RM0394), Rev 4
 *            Sections 37 (I2C) – register map p.1036
 ******************************************************************************
 */

#ifndef STM32L41X_I2C_H
#define STM32L41X_I2C_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* =========================================================================
 * Peripheral Base Addresses (STM32L41xxx)
 * ========================================================================= */
#define I2C1_BASE           0x40005400UL
#define I2C3_BASE           0x40005C00UL

/* =========================================================================
 * Register Map (offset from peripheral base)
 * ========================================================================= */
typedef struct {
    volatile uint32_t CR1;          /*!< 0x00 Control register 1            */
    volatile uint32_t CR2;          /*!< 0x04 Control register 2            */
    volatile uint32_t OAR1;         /*!< 0x08 Own address register 1        */
    volatile uint32_t OAR2;         /*!< 0x0C Own address register 2        */
    volatile uint32_t TIMINGR;      /*!< 0x10 Timing register               */
    volatile uint32_t TIMEOUTR;     /*!< 0x14 Timeout register              */
    volatile uint32_t ISR;          /*!< 0x18 Interrupt and status register */
    volatile uint32_t ICR;          /*!< 0x1C Interrupt clear register      */
    volatile uint32_t PECR;         /*!< 0x20 PEC register                  */
    volatile uint32_t RXDR;         /*!< 0x24 Receive data register         */
    volatile uint32_t TXDR;         /*!< 0x28 Transmit data register        */
} I2C_TypeDef;

#define I2C1    ((I2C_TypeDef *)I2C1_BASE)
#define I2C3    ((I2C_TypeDef *)I2C3_BASE)

/* =========================================================================
 * CR1 Bit Definitions
 * ========================================================================= */
#define I2C_CR1_PE              (1UL << 0)   /*!< Peripheral enable              */
#define I2C_CR1_TXIE            (1UL << 1)   /*!< TX interrupt enable            */
#define I2C_CR1_RXIE            (1UL << 2)   /*!< RX interrupt enable            */
#define I2C_CR1_ADDRIE          (1UL << 3)   /*!< Address match interrupt enable */
#define I2C_CR1_NACKIE          (1UL << 4)   /*!< NACK interrupt enable          */
#define I2C_CR1_STOPIE          (1UL << 5)   /*!< STOP detection interrupt enable*/
#define I2C_CR1_TCIE            (1UL << 6)   /*!< Transfer complete int enable   */
#define I2C_CR1_ERRIE           (1UL << 7)   /*!< Error interrupt enable         */
#define I2C_CR1_DNF_Pos         8U
#define I2C_CR1_DNF_Msk         (0xFUL << I2C_CR1_DNF_Pos) /*!< Digital noise filter */
#define I2C_CR1_ANFOFF          (1UL << 12)  /*!< Analog noise filter OFF        */
#define I2C_CR1_TXDMAEN         (1UL << 14)  /*!< DMA TX requests enable         */
#define I2C_CR1_RXDMAEN         (1UL << 15)  /*!< DMA RX requests enable         */
#define I2C_CR1_SBC             (1UL << 16)  /*!< Slave byte control             */
#define I2C_CR1_NOSTRETCH       (1UL << 17)  /*!< Clock stretching disable       */
#define I2C_CR1_WUPEN           (1UL << 18)  /*!< Wakeup from STOP enable        */
#define I2C_CR1_GCEN            (1UL << 19)  /*!< General call enable            */
#define I2C_CR1_SMBHEN          (1UL << 20)  /*!< SMBus host address enable      */
#define I2C_CR1_SMBDEN          (1UL << 21)  /*!< SMBus device default addr en   */
#define I2C_CR1_ALERTEN         (1UL << 22)  /*!< SMBus alert enable             */
#define I2C_CR1_PECEN           (1UL << 23)  /*!< PEC enable                     */

/* =========================================================================
 * CR2 Bit Definitions
 * ========================================================================= */
#define I2C_CR2_SADD_Pos        0U
#define I2C_CR2_SADD_Msk        (0x3FFUL << I2C_CR2_SADD_Pos) /*!< Slave address      */
#define I2C_CR2_RD_WRN          (1UL << 10)  /*!< Transfer direction (1=Read)    */
#define I2C_CR2_ADD10           (1UL << 11)  /*!< 10-bit addressing mode         */
#define I2C_CR2_HEAD10R         (1UL << 12)  /*!< 10-bit addr header only read   */
#define I2C_CR2_START           (1UL << 13)  /*!< START generation               */
#define I2C_CR2_STOP            (1UL << 14)  /*!< STOP generation                */
#define I2C_CR2_NACK            (1UL << 15)  /*!< NACK generation                */
#define I2C_CR2_NBYTES_Pos      16U
#define I2C_CR2_NBYTES_Msk      (0xFFUL << I2C_CR2_NBYTES_Pos) /*!< Byte count  */
#define I2C_CR2_RELOAD          (1UL << 24)  /*!< NBYTES reload mode             */
#define I2C_CR2_AUTOEND         (1UL << 25)  /*!< Automatic end mode             */
#define I2C_CR2_PECBYTE         (1UL << 26)  /*!< Packet error checking byte     */

/* =========================================================================
 * ISR Bit Definitions
 * ========================================================================= */
#define I2C_ISR_TXE             (1UL << 0)   /*!< Transmit data register empty   */
#define I2C_ISR_TXIS            (1UL << 1)   /*!< Transmit interrupt status      */
#define I2C_ISR_RXNE            (1UL << 2)   /*!< Receive data register not empty*/
#define I2C_ISR_ADDR            (1UL << 3)   /*!< Address matched                */
#define I2C_ISR_NACKF           (1UL << 4)   /*!< Not acknowledge received       */
#define I2C_ISR_STOPF           (1UL << 5)   /*!< STOP detection flag            */
#define I2C_ISR_TC              (1UL << 6)   /*!< Transfer complete              */
#define I2C_ISR_TCR             (1UL << 7)   /*!< Transfer complete reload       */
#define I2C_ISR_BERR            (1UL << 8)   /*!< Bus error                      */
#define I2C_ISR_ARLO            (1UL << 9)   /*!< Arbitration lost               */
#define I2C_ISR_OVR             (1UL << 10)  /*!< Overrun/Underrun               */
#define I2C_ISR_PECERR          (1UL << 11)  /*!< PEC error                      */
#define I2C_ISR_TIMEOUT         (1UL << 12)  /*!< Timeout                        */
#define I2C_ISR_ALERT           (1UL << 13)  /*!< SMBus alert                    */
#define I2C_ISR_BUSY            (1UL << 15)  /*!< Bus busy                       */
#define I2C_ISR_DIR             (1UL << 16)  /*!< Transfer direction (slave)     */
#define I2C_ISR_ADDCODE_Pos     17U
#define I2C_ISR_ADDCODE_Msk     (0x7FUL << I2C_ISR_ADDCODE_Pos)

/* =========================================================================
 * ICR Bit Definitions
 * ========================================================================= */
#define I2C_ICR_ADDRCF          (1UL << 3)
#define I2C_ICR_NACKCF          (1UL << 4)
#define I2C_ICR_STOPCF          (1UL << 5)
#define I2C_ICR_BERRCF          (1UL << 8)
#define I2C_ICR_ARLOCF          (1UL << 9)
#define I2C_ICR_OVRCF           (1UL << 10)
#define I2C_ICR_PECCF           (1UL << 11)
#define I2C_ICR_TIMOUTCF        (1UL << 12)
#define I2C_ICR_ALERTCF         (1UL << 13)

/* =========================================================================
 * TIMINGR Pre-computed Values
 * Calculated for PCLK1 = 16 MHz (HSI), 80 MHz via PLL.
 * Use STM32CubeMX or AN4235 to calculate for other clock sources.
 * ========================================================================= */

/** @defgroup I2C_Timing_16MHz PCLK1 = 16 MHz (HSI) */
#define I2C_TIMING_100K_16MHZ   0x00503D5AU  /*!< 100 kHz @ PCLK1=16 MHz  */
#define I2C_TIMING_400K_16MHZ   0x00300F38U  /*!< 400 kHz @ PCLK1=16 MHz  */
#define I2C_TIMING_1M_16MHZ     0x00200205U  /*!< 1 MHz   @ PCLK1=16 MHz  */

/** @defgroup I2C_Timing_80MHz PCLK1 = 80 MHz (PLL) */
#define I2C_TIMING_100K_80MHZ   0x10909CECU  /*!< 100 kHz @ PCLK1=80 MHz  */
#define I2C_TIMING_400K_80MHZ   0x00702991U  /*!< 400 kHz @ PCLK1=80 MHz  */
#define I2C_TIMING_1M_80MHZ     0x00300F33U  /*!< 1 MHz   @ PCLK1=80 MHz  */

/* =========================================================================
 * Driver Configuration
 * ========================================================================= */
#define I2C_TIMEOUT_MS          100U    /*!< Default polling timeout (ms)   */
#define I2C_MAX_NBYTES          255U    /*!< Max bytes per single transfer   */
#define I2C_BUS_FREE_TIMEOUT    25U     /*!< Bus-free check timeout (ms)     */

/* =========================================================================
 * Enumerations
 * ========================================================================= */

/** I2C operating speed mode */
typedef enum {
    I2C_SPEED_STANDARD  = 0,   /*!< 100 kHz */
    I2C_SPEED_FAST      = 1,   /*!< 400 kHz */
    I2C_SPEED_FAST_PLUS = 2,   /*!< 1 MHz   */
} I2C_SpeedMode_t;

/** I2C addressing mode */
typedef enum {
    I2C_ADDR_7BIT  = 0,        /*!< 7-bit slave address  */
    I2C_ADDR_10BIT = 1,        /*!< 10-bit slave address */
} I2C_AddrMode_t;

/** I2C transfer direction */
typedef enum {
    I2C_DIR_WRITE = 0,         /*!< Master to slave */
    I2C_DIR_READ  = 1,         /*!< Slave to master */
} I2C_Direction_t;

/** Driver operation mode */
typedef enum {
    I2C_MODE_POLLING   = 0,    /*!< CPU polls status flags      */
    I2C_MODE_INTERRUPT = 1,    /*!< ISR-driven transfers        */
    I2C_MODE_DMA       = 2,    /*!< DMA-driven transfers        */
} I2C_OperationMode_t;

/** Driver state machine */
typedef enum {
    I2C_STATE_RESET    = 0x00, /*!< Not initialized             */
    I2C_STATE_READY    = 0x01, /*!< Ready for new transfer      */
    I2C_STATE_BUSY_TX  = 0x02, /*!< Transmitting                */
    I2C_STATE_BUSY_RX  = 0x03, /*!< Receiving                   */
    I2C_STATE_LISTEN   = 0x04, /*!< Slave listening             */
    I2C_STATE_BUSY_TX_LISTEN = 0x12, /*!< Slave TX (addr matched) */
    I2C_STATE_BUSY_RX_LISTEN = 0x13, /*!< Slave RX (addr matched) */
    I2C_STATE_ABORT    = 0x60, /*!< Abort requested             */
    I2C_STATE_TIMEOUT  = 0xA0, /*!< Timeout error               */
    I2C_STATE_ERROR    = 0xE0, /*!< Error state                 */
} I2C_State_t;

/** Error codes (bitmask) */
typedef enum {
    I2C_ERR_NONE    = 0x00,
    I2C_ERR_BERR    = 0x01,    /*!< Bus error (misplaced START/STOP) */
    I2C_ERR_ARLO    = 0x02,    /*!< Arbitration lost                 */
    I2C_ERR_OVR     = 0x04,    /*!< Overrun / underrun               */
    I2C_ERR_PECERR  = 0x08,    /*!< PEC check failure                */
    I2C_ERR_TIMEOUT = 0x10,    /*!< Timeout                          */
    I2C_ERR_NACK    = 0x20,    /*!< NACK received from slave         */
    I2C_ERR_PARAM   = 0x40,    /*!< Invalid parameter                */
    I2C_ERR_BUSY    = 0x80,    /*!< Bus busy / driver busy           */
} I2C_Error_t;

/** Function return status */
typedef enum {
    I2C_OK      = 0,
    I2C_FAIL    = 1,
    I2C_BUSY    = 2,
    I2C_TIMEOUT = 3,
} I2C_Status_t;

/* =========================================================================
 * Configuration Structure
 * ========================================================================= */
typedef struct {
    uint32_t            timing;         /*!< TIMINGR register value (use macros above) */
    I2C_AddrMode_t      addr_mode;      /*!< 7-bit or 10-bit addressing                */
    uint16_t            own_addr1;      /*!< Own address 1 (slave mode)                */
    uint16_t            own_addr2;      /*!< Own address 2 (dual address slave)        */
    uint8_t             own_addr2_mask; /*!< OA2 masking (0=exact, 1-7=mask bits)      */
    bool                general_call;   /*!< Accept general call address               */
    bool                no_stretch;     /*!< Disable clock stretching (slave)          */
    I2C_OperationMode_t op_mode;        /*!< Polling / Interrupt / DMA                 */
    uint8_t             dnf;            /*!< Digital noise filter (0–15 tPCLK cycles) */
    bool                analog_filter;  /*!< Enable analog noise filter                */
} I2C_Config_t;

/* =========================================================================
 * Handle Structure
 * ========================================================================= */
typedef struct I2C_Handle_s I2C_Handle_t;

struct I2C_Handle_s {
    I2C_TypeDef        *instance;       /*!< Pointer to I2C peripheral registers       */
    I2C_Config_t        config;         /*!< Driver configuration                      */
    volatile I2C_State_t state;         /*!< Current driver state                      */
    volatile I2C_Error_t error;         /*!< Accumulated error flags                   */

    /* Transfer context (interrupt/DMA) */
    uint8_t            *tx_buf;         /*!< Pointer to TX data buffer                 */
    volatile uint16_t   tx_count;       /*!< Remaining TX bytes                        */
    uint8_t            *rx_buf;         /*!< Pointer to RX data buffer                 */
    volatile uint16_t   rx_count;       /*!< Remaining RX bytes                        */
    uint16_t            dev_addr;       /*!< Current target device address             */
    uint16_t            xfer_size;      /*!< Total transfer size (reload support)      */
    volatile uint16_t   xfer_count;     /*!< Number of bytes transferred               */

    /* Slave context */
    volatile uint16_t   slave_addr;     /*!< Matched slave address                     */
    volatile bool       slave_rx_done;  /*!< Slave reception complete flag             */

    /* User callbacks (set to NULL to disable) */
    void (*cb_master_tx_complete)(I2C_Handle_t *hi2c);
    void (*cb_master_rx_complete)(I2C_Handle_t *hi2c);
    void (*cb_slave_tx_complete) (I2C_Handle_t *hi2c);
    void (*cb_slave_rx_complete) (I2C_Handle_t *hi2c);
    void (*cb_addr_match)        (I2C_Handle_t *hi2c, uint8_t direction, uint16_t addr);
    void (*cb_listen_complete)   (I2C_Handle_t *hi2c);
    void (*cb_error)             (I2C_Handle_t *hi2c);

    /* Platform tick function (returns ms tick, e.g. SysTick-based) */
    uint32_t (*get_tick_ms)(void);
};

/* =========================================================================
 * Public API
 * ========================================================================= */

/**
 * @brief  Initialise the I2C peripheral.
 * @param  hi2c  Pointer to the handle (instance + config must be filled).
 * @retval I2C_OK on success.
 */
I2C_Status_t I2C_Init(I2C_Handle_t *hi2c);

/**
 * @brief  De-initialise and disable the I2C peripheral.
 */
I2C_Status_t I2C_DeInit(I2C_Handle_t *hi2c);

/**
 * @brief  Reset I2C peripheral (software reset then re-enable).
 */
I2C_Status_t I2C_Reset(I2C_Handle_t *hi2c);

/* ── Master Polling ─────────────────────────────────────────────────────── */

/**
 * @brief  Master transmit (polling).
 * @param  hi2c      Handle.
 * @param  dev_addr  7-bit slave address (unshifted).
 * @param  pdata     Pointer to data buffer.
 * @param  size      Number of bytes to send.
 * @param  timeout   Timeout in milliseconds.
 */
I2C_Status_t I2C_Master_Transmit(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                  const uint8_t *pdata, uint16_t size,
                                  uint32_t timeout);

/**
 * @brief  Master receive (polling).
 */
I2C_Status_t I2C_Master_Receive(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                 uint8_t *pdata, uint16_t size,
                                 uint32_t timeout);

/**
 * @brief  Write to a register address then read back (combined Wr+Rd with ReSTART).
 * @param  hi2c      Handle.
 * @param  dev_addr  7-bit device address.
 * @param  reg_addr  Register/memory address bytes.
 * @param  reg_size  Number of address bytes (1 or 2).
 * @param  pdata     Buffer for received data.
 * @param  size      Number of data bytes to read.
 * @param  timeout   Timeout in milliseconds.
 */
I2C_Status_t I2C_Mem_Read(I2C_Handle_t *hi2c, uint16_t dev_addr,
                           uint16_t reg_addr, uint8_t reg_size,
                           uint8_t *pdata, uint16_t size,
                           uint32_t timeout);

/**
 * @brief  Write to a register address (addr bytes + data bytes).
 */
I2C_Status_t I2C_Mem_Write(I2C_Handle_t *hi2c, uint16_t dev_addr,
                            uint16_t reg_addr, uint8_t reg_size,
                            const uint8_t *pdata, uint16_t size,
                            uint32_t timeout);

/* ── Master Interrupt ───────────────────────────────────────────────────── */

I2C_Status_t I2C_Master_Transmit_IT(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                     const uint8_t *pdata, uint16_t size);

I2C_Status_t I2C_Master_Receive_IT(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                    uint8_t *pdata, uint16_t size);

/* ── Slave ──────────────────────────────────────────────────────────────── */

I2C_Status_t I2C_Slave_Transmit(I2C_Handle_t *hi2c, const uint8_t *pdata,
                                  uint16_t size, uint32_t timeout);

I2C_Status_t I2C_Slave_Receive(I2C_Handle_t *hi2c, uint8_t *pdata,
                                 uint16_t size, uint32_t timeout);

I2C_Status_t I2C_Slave_Transmit_IT(I2C_Handle_t *hi2c, const uint8_t *pdata,
                                     uint16_t size);

I2C_Status_t I2C_Slave_Receive_IT(I2C_Handle_t *hi2c, uint8_t *pdata,
                                    uint16_t size);

/** Enable slave listen mode (address-match interrupt only) */
I2C_Status_t I2C_Slave_Listen_IT(I2C_Handle_t *hi2c);

/** Disable slave listen mode */
I2C_Status_t I2C_Slave_StopListen_IT(I2C_Handle_t *hi2c);

/* ── Utility ────────────────────────────────────────────────────────────── */

/**
 * @brief  Probe bus for a device (sends address, checks ACK).
 * @retval I2C_OK if device responds, I2C_FAIL otherwise.
 */
I2C_Status_t I2C_IsDeviceReady(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                 uint32_t trials, uint32_t timeout);

/** @brief  Return accumulated error flags and clear them. */
I2C_Error_t  I2C_GetError(I2C_Handle_t *hi2c);

/** @brief  Return current driver state. */
I2C_State_t  I2C_GetState(I2C_Handle_t *hi2c);

/** @brief  Abort an ongoing IT/DMA transfer and release the bus. */
I2C_Status_t I2C_Abort_IT(I2C_Handle_t *hi2c);

/* ── IRQ Handlers (call from NVIC vectors) ──────────────────────────────── */

/**
 * @brief  Handle I2C event interrupt (EV).
 *         Map to I2C1_EV_IRQHandler / I2C3_EV_IRQHandler.
 */
void I2C_EV_IRQHandler(I2C_Handle_t *hi2c);

/**
 * @brief  Handle I2C error interrupt (ER).
 *         Map to I2C1_ER_IRQHandler / I2C3_ER_IRQHandler.
 */
void I2C_ER_IRQHandler(I2C_Handle_t *hi2c);

#ifdef __cplusplus
}
#endif

#endif /* STM32L41X_I2C_H */
